To run the application:

Open DemoApplication.java in IntelliJ IDEA.
Right-click on DemoApplication class.
Select Run DemoApplication.main() from the context menu.
This will start your Spring Boot application. You can then access the endpoint http://localhost:8080/users/info to see the response "User information fetched successfully!" from the UserController.