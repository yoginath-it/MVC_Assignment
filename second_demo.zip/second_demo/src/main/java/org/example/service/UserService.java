package org.example.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {

    public void getInfo() {
        System.out.println("Fetching user information...");
        // Other logic related to fetching user information
    }
}
