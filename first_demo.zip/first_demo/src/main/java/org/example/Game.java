package org.example;

public interface Game {
    void up();
    void down();
    void left();
    void right();
}
